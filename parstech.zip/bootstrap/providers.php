<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\JalaliServiceProvider::class,
    App\Providers\SidebarServiceProvider::class,
    App\Providers\VertaServiceProvider::class,
];
