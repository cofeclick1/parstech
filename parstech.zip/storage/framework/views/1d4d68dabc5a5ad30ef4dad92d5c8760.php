<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>سحابداری خدمات کامپیوتری</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/landing.css')); ?>">
</head>
<body>
    <nav>
        <a href="<?php echo e(route('login')); ?>">ورود</a> |
        <a href="<?php echo e(route('register')); ?>">ثبت‌نام</a>
    </nav>
    <section class="hero">
        <h1>به سحابداری خدمات کامپیوتری خوش آمدید</h1>
        <p>مدیریت آسان درآمد، هزینه و مشتریان مغازه شما</p>
        <a href="<?php echo e(route('register')); ?>" class="cta">همین حالا شروع کنید</a>
    </section>
    <footer>
        <p>© 2025 سحابداری. طراحی شده توسط شما</p>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/landing.blade.php ENDPATH**/ ?>