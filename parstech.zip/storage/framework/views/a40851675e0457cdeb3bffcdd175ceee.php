<section>
    <header>
        <h2 class="text-lg font-medium text-danger">
            حذف حساب کاربری
        </h2>
        <p class="mt-1 text-sm text-secondary">
            با حذف حساب، تمام اطلاعات شما پاک می‌شود. لطفاً رمز عبور را وارد کنید.
        </p>
    </header>
    <form method="post" action="<?php echo e(route('profile.destroy')); ?>" class="mt-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <div class="mb-3">
            <label for="delete_password" class="form-label">رمز عبور</label>
            <input id="delete_password" name="password" type="password" class="form-control" required>
            <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-outline-danger">حذف حساب</button>
    </form>
</section>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>