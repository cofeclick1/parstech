<section>
    <header>
        <h2 class="text-lg font-medium text-dark">
            اطلاعات کاربری
        </h2>
        <p class="mt-1 text-sm text-secondary">
            اطلاعات حساب خود را ویرایش کنید.
        </p>
    </header>
    <form method="post" action="<?php echo e(route('profile.update')); ?>" class="mt-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">نام و نام خانوادگی</label>
            <input id="name" name="name" type="text" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required autofocus autocomplete="name" />
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">ایمیل</label>
            <input id="email" name="email" type="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username" />
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-success">ذخیره اطلاعات</button>
        <?php if(session('status') === 'profile-updated'): ?>
            <span class="text-success ms-3">اطلاعات با موفقیت ذخیره شد.</span>
        <?php endif; ?>
    </form>
</section>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>