<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'سحابداری'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Bootstrap & استایل‌های پروژه -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-iconpicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/category-advanced.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/category-form.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/person-create.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    <div class="wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- اسکریپت‌های مورد نیاز اگر داشتی -->
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'موفق!',
        text: '<?php echo e(session('success')); ?>',
        confirmButtonText: 'باشه'
    });
</script>
<?php endif; ?>
<?php if($errors->any()): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'خطا!',
        html: "<?php echo implode('<br>', $errors->all()); ?>",
        confirmButtonText: 'باشه'
    });
</script>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/layouts/master.blade.php ENDPATH**/ ?>