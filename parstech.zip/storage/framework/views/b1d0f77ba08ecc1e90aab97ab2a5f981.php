<?php $__env->startSection('title', 'لیست محصولات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0">لیست محصولات</h4>
            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success">افزودن محصول جدید</a>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>کد</th>
                        <th>دسته‌بندی</th>
                        <th>برند</th>
                        <th>قیمت فروش</th>
                        <th>موجودی</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->code); ?></td>
                            <td><?php echo e($product->category?->name ?? '-'); ?></td>
                            <td><?php echo e($product->brand?->name ?? '-'); ?></td>
                            <td><?php echo e(number_format($product->sell_price)); ?></td>
                            <td><?php echo e($product->stock); ?></td>
                            <td>
                                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-info btn-sm">نمایش</a>
                                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning btn-sm">ویرایش</a>
                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm" onclick="return confirm('آیا مطمئن هستید؟')">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-danger">محصولی یافت نشد.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="d-flex justify-content-center">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\parstech\resources\views/products/index.blade.php ENDPATH**/ ?>