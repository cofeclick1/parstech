<?php $__env->startSection('title', 'لیست دسته‌بندی‌ها'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/category-invoice-table.css')); ?>">

<div class="container mx-auto px-4 py-6">
    <div class="bg-white shadow-lg rounded-lg overflow-x-auto p-4">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-2xl font-bold text-gray-700">لیست دسته‌بندی‌ها</h2>
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success text-white px-4 py-2 rounded-md">افزودن دسته‌بندی</a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success mb-4"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger mb-4">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="category-invoice-table w-full min-w-[700px]">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>کد</th>
                        <th>نوع</th>
                        <th>زیر دسته‌ها</th>
                        <th class="text-center">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="main-row">
                            <td>
                                <div class="font-semibold text-slate-700"><?php echo e($cat->name); ?></div>
                            </td>
                            <td>
                                <span class="invoice-badge invoice-badge-blue"><?php echo e($cat->code); ?></span>
                            </td>
                            <td>
                                <span class="invoice-badge invoice-badge-type-<?php echo e($cat->category_type); ?>">
                                    <?php echo e(categoryTypeFa($cat->category_type)); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($cat->children->count() > 0): ?>
                                    <ul class="subcat-list">
                                        <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <span class="font-semibold text-indigo-700"><?php echo e($sub->name); ?></span>
                                                <span class="invoice-badge invoice-badge-blue"><?php echo e($sub->code); ?></span>
                                                <span class="invoice-badge invoice-badge-type-<?php echo e($sub->category_type); ?>">
                                                    <?php echo e(categoryTypeFa($sub->category_type)); ?>

                                                </span>
                                                <a href="<?php echo e(route('categories.edit', $sub->id)); ?>" class="action-btn edit" title="ویرایش"><i class="fa fa-edit"></i></a>
                                                <form method="POST" action="<?php echo e(route('categories.destroy', $sub->id)); ?>" class="d-inline" onsubmit="return confirm('حذف این زیر دسته؟');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="action-btn delete" type="submit" title="حذف"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    <span class="text-slate-400">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('categories.edit', $cat->id)); ?>" class="action-btn edit" title="ویرایش"><i class="fa fa-edit"></i></a>
                                <form method="POST" action="<?php echo e(route('categories.destroy', $cat->id)); ?>" class="d-inline" onsubmit="return confirm('حذف این دسته؟');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="action-btn delete" type="submit" title="حذف"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($categories->count() == 0): ?>
                        <tr>
                            <td colspan="5" class="text-center text-slate-400 py-4">دسته‌ای وجود ندارد.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\parstech\resources\views/categories/index.blade.php ENDPATH**/ ?>