<section>
    <header>
        <h2 class="text-lg font-medium text-dark">
            تغییر رمز عبور
        </h2>
        <p class="mt-1 text-sm text-secondary">
            رمز عبور قوی و غیرقابل حدس انتخاب کنید.
        </p>
    </header>
    <form method="post" action="<?php echo e(route('password.update')); ?>" class="mt-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="mb-3">
            <label for="current_password" class="form-label">رمز عبور فعلی</label>
            <input id="current_password" name="current_password" type="password" class="form-control" autocomplete="current-password" />
            <?php $__errorArgs = ['current_password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">رمز عبور جدید</label>
            <input id="password" name="password" type="password" class="form-control" autocomplete="new-password" />
            <?php $__errorArgs = ['password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="password_confirmation" class="form-label">تکرار رمز عبور جدید</label>
            <input id="password_confirmation" name="password_confirmation" type="password" class="form-control" autocomplete="new-password" />
            <?php $__errorArgs = ['password_confirmation', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-primary">ذخیره رمز عبور</button>
        <?php if(session('status') === 'password-updated'): ?>
            <span class="text-success ms-3">رمز عبور با موفقیت تغییر کرد.</span>
        <?php endif; ?>
    </form>
</section>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>