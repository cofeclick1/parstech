<section>
    <header>
        <h2 class="text-lg font-medium text-dark">
            تغییر تصویر پروفایل
        </h2>
        <p class="mt-1 text-sm text-secondary">
            تصویر جدید بارگذاری کنید.
        </p>
    </header>
    <form method="post" action="<?php echo e(route('profile.avatar.update')); ?>" enctype="multipart/form-data" class="mt-4">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <input type="file" name="avatar" class="form-control" accept="image/*" required>
            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-info">ذخیره تصویر</button>
        <?php if(session('status') === 'avatar-updated'): ?>
            <span class="text-success ms-3">تصویر با موفقیت تغییر کرد.</span>
        <?php endif; ?>
    </form>
</section>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/profile/partials/update-avatar-form.blade.php ENDPATH**/ ?>