<?php $__env->startSection('title', 'افزودن برند جدید'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2>افزودن برند جدید</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <form action="<?php echo e(route('brands.store')); ?>" method="POST" enctype="multipart/form-data" class="card p-4">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">
                نام برند <span class="text-danger">*</span>
            </label>
            <input type="text" name="name" class="form-control" required value="<?php echo e(old('name')); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">
                تصویر برند
            </label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>
        <button class="btn btn-success">
            ثبت برند
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\parstech\resources\views/brands/create.blade.php ENDPATH**/ ?>