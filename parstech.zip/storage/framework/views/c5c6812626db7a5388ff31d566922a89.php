<div class="sales-form-section mb-3">
    <ul class="nav nav-tabs sales-product-tabs" id="productTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="products-tab" data-bs-toggle="tab" data-bs-target="#products-pane" type="button" role="tab">محصولات</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="services-tab" data-bs-toggle="tab" data-bs-target="#services-pane" type="button" role="tab">خدمات</button>
        </li>
    </ul>
    <div class="tab-content" id="productTabsContent">
        <div class="tab-pane fade show active" id="products-pane" role="tabpanel">
            <?php echo $__env->make('sales.partials.product_list_inner', ['type' => 'product'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <div class="tab-pane fade" id="services-pane" role="tabpanel">
            <?php echo $__env->make('sales.partials.product_list_inner', ['type' => 'service'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/sales/partials/product_list.blade.php ENDPATH**/ ?>