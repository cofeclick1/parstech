<?php $__env->startSection('title', 'لیست خدمات'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/service-index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content pt-4">
    <div class="container-fluid">
        <div class="card card-outline card-primary shadow">
            <div class="card-header service-colored" id="service-header">
                <h5 class="mb-0">لیست خدمات</h5>
                <a href="<?php echo e(route('services.create')); ?>" class="btn btn-success float-left">افزودن خدمات جدید</a>
            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <tr>
                                <th>ردیف</th>
                                <th>عنوان خدمات</th>
                                <th>کد خدمات</th>
                                <th>دسته‌بندی</th>
                                <th>واحد</th>
                                <th>قیمت</th>
                                <th>وضعیت</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($service->title); ?></td>
                                    <td><?php echo e($service->service_code); ?></td>
                                    <td>
                                        <?php
                                            $cat = $serviceCategories->firstWhere('id', $service->service_category_id);
                                        ?>
                                        <?php echo e($cat ? $cat->name : '-'); ?>

                                    </td>
                                    <td><?php echo e($service->unit); ?></td>
                                    <td><?php echo e(number_format($service->price)); ?></td>
                                    <td>
                                        <?php if($service->is_active): ?>
                                            <span class="badge badge-success">فعال</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">غیرفعال</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('services.edit', $service->id)); ?>" class="btn btn-sm btn-info">ویرایش</a>
                                        <form action="<?php echo e(route('services.destroy', $service->id)); ?>" method="POST" style="display:inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('از حذف مطمئن هستید؟')">حذف</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8">هیچ خدمتی ثبت نشده است.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div>
                    <?php echo e($services->links()); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\parstech\resources\views/services/index.blade.php ENDPATH**/ ?>