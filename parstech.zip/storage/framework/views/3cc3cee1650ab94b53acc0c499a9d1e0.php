<?php $__env->startSection('title', 'افزودن خدمت جدید'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/service-create.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@formkit/themes@1.0.0-beta.3/genesis/theme.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="container pt-4">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card shadow">
                <div class="card-header bg-info text-white">
                    <h4 class="mb-0">
                        <i class="fa fa-plus-circle me-2"></i>افزودن خدمت جدید
                    </h4>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('services.store')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        <!-- عنوان خدمت -->
                        <div class="mb-3">
                            <label for="title" class="form-label required">
                                عنوان خدمت <span class="text-muted fs-7">(مثال: ثبت‌نام خودرو، پرداخت قبض، تعمیر موبایل، تمدید بیمه و...)</span>
                            </label>
                            <input type="text" name="title" id="title" class="form-control" required autofocus value="<?php echo e(old('title')); ?>">
                        </div>

                        <!-- دسته‌بندی خدمت (اختیاری) -->
                        <div class="mb-3">
                            <label for="service_category_id" class="form-label">دسته‌بندی خدمت (اختیاری)</label>
                            <select name="service_category_id" id="service_category_id" class="form-select">
                                <option value="">انتخاب کنید</option>
                                <?php $__currentLoopData = $serviceCategories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php echo e(old('service_category_id') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- قیمت خدمت -->
                        <div class="mb-3">
                            <label for="price" class="form-label required">قیمت خدمت (تومان)</label>
                            <input type="number" name="price" id="price" class="form-control" required min="0" value="<?php echo e(old('price')); ?>">
                        </div>

                        <!-- توضیح کوتاه -->
                        <div class="mb-3">
                            <label for="short_description" class="form-label">توضیح کوتاه (اختیاری)</label>
                            <input type="text" name="short_description" id="short_description" class="form-control" maxlength="255" value="<?php echo e(old('short_description')); ?>">
                        </div>

                        <!-- توضیح کامل -->
                        <div class="mb-3">
                            <label for="description" class="form-label">توضیحات کامل (اختیاری)</label>
                            <textarea name="description" id="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
                        </div>

                        <!-- آپلود تصویر (اختیاری) -->
                        <div class="mb-3">
                            <label for="image" class="form-label">تصویر خدمت (اختیاری)</label>
                            <input type="file" name="image" id="image" class="form-control" accept="image/*">
                        </div>

                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-success px-4">
                                <i class="fa fa-save me-1"></i>ثبت خدمت
                            </button>
                        </div>
                    </form>

                    <!-- فرم‌ساز داینامیک برای تعریف فرم اختصاصی هر خدمت -->
                    <hr class="my-4">
                    <h5 class="mb-3 text-primary">فرم اختصاصی اطلاعات مشتری برای این خدمت (اختیاری):</h5>
                    <div id="dynamic-service-form"></div>
                </div>
            </div>

            <div class="alert alert-info mt-4">
                <strong>راهنما:</strong>
                <ul class="mb-1">
                    <li>برای خدمات کافی‌نت (مثل ثبت‌نام، پرداخت، تعمیر و...) فقط عنوان و قیمت را وارد کنید، تعداد نیاز نیست.</li>
                    <li>دسته‌بندی و تصویر اختیاری است و برای دسته‌بندی بهتر خدمات می‌توان استفاده کرد.</li>
                    <li>لیست خدمات پیشنهادی: ثبت‌نام وام، ثبت‌نام خودرو، تمدید بیمه، تعمیرات کامپیوتر و موبایل، پرداخت قبوض و...</li>
                </ul>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\parstech\resources\views/services/create.blade.php ENDPATH**/ ?>