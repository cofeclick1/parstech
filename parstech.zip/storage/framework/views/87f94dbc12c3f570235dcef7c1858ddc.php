<?php
    $tabType = $type ?? 'product'; // 'product' or 'service'
?>

<div class="mb-2">
    <input type="text" class="form-control sales-form-input mb-2"
           id="<?php echo e($tabType); ?>-search-input"
           placeholder="جستجو در <?php echo e($tabType == 'product' ? 'محصولات' : 'خدمات'); ?> ...">
</div>
<div class="table-responsive sales-product-table-container">
    <table class="table table-hover align-middle sales-product-table">
        <thead>
        <tr>
            <th>افزودن</th>
            <th>کد</th>
            <?php if($tabType == 'product'): ?>
                <th>تصویر</th>
            <?php endif; ?>
            <th>نام</th>
            <?php if($tabType == 'product'): ?>
                <th>موجودی</th>
            <?php endif; ?>
            <th>دسته‌بندی</th>
            <th>قیمت فروش</th>
            <th>توضیحات</th>
        </tr>
        </thead>
        <tbody id="<?php echo e($tabType); ?>-table-body">
        <!-- Ajax: لیست محصولات یا خدمات -->
        </tbody>
    </table>
    <div class="text-center py-2">
        <button class="btn btn-outline-primary d-none" id="<?php echo e($tabType); ?>-load-more-btn">
            <i class="fa-solid fa-arrow-down ms-1"></i>
            بارگذاری بیشتر
        </button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\parstech\resources\views/sales/partials/product_list_inner.blade.php ENDPATH**/ ?>