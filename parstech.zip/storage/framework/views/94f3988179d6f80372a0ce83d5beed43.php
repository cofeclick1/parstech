<?php $__env->startSection('title', 'لیست اشخاص'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12">
            <h3 class="mb-4">لیست اشخاص</h3>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <a href="<?php echo e(route('persons.create')); ?>" class="btn btn-primary mb-3">افزودن شخص جدید</a>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>کد حسابداری</th>
                            <th>نام</th>
                            <th>نام خانوادگی</th>
                            <th>نوع</th>
                            <th>شرکت</th>
                            <th>موبایل</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($person->accounting_code); ?></td>
                                <td><?php echo e($person->first_name); ?></td>
                                <td><?php echo e($person->last_name); ?></td>
                                <td><?php echo e($person->type); ?></td>
                                <td><?php echo e($person->company_name); ?></td>
                                <td><?php echo e($person->mobile); ?></td>
                                <td>
                                    <a href="<?php echo e(route('persons.show', $person)); ?>" class="btn btn-sm btn-info">نمایش</a>
                                    <a href="<?php echo e(route('persons.edit', $person)); ?>" class="btn btn-sm btn-warning">ویرایش</a>
                                    <form action="<?php echo e(route('persons.destroy', $person)); ?>" method="POST" class="d-inline"
                                        onsubmit="return confirm('آیا از حذف این شخص مطمئن هستید؟');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger" type="submit">حذف</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">هیچ شخصی ثبت نشده است.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div>
                <?php echo e($persons->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\parstech\resources\views/persons/index.blade.php ENDPATH**/ ?>