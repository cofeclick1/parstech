<div class="table-responsive">
    <table class="table align-middle table-bordered sales-invoice-items-table">
        <thead>
        <tr>
            <th>حذف</th>
            <th>کالا/خدمت</th>
            <th>شرح</th>
            <th>واحد</th>
            <th>تعداد</th>
            <th>مبلغ واحد</th>
            <th>تخفیف</th>
            <th>مالیات</th>
            <th>مبلغ کل</th>
        </tr>
        </thead>
        <tbody id="invoice-items-body">
        <!-- آیتم‌های فاکتور توسط JS اضافه می‌شوند -->
        </tbody>
        <tfoot>
        <tr>
            <td colspan="8" class="text-end">جمع کل:</td>
            <td id="invoice-total-amount">۰ ریال</td>
        </tr>
        </tfoot>
    </table>
</div>
