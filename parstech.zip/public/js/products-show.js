document.addEventListener('DOMContentLoaded', function () {
    // اگر نیاز به فانکشن خاصی داری بگو.
    // مثلا: اسکرول خودکار به بخش خاص، افکت روی گالری ویدیو و عکس و ...
});
