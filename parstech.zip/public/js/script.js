document.addEventListener('DOMContentLoaded', function () {
    console.log('صفحه به درستی بارگذاری شد!');
});
