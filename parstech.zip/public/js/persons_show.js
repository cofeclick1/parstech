document.addEventListener('DOMContentLoaded', function () {
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', function () {
            // فرم جستجو با ارسال معمولی کار می‌کند.
        });
    }
});
